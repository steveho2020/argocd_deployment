# hello-world-k8s
Kubernetes "Hello World" Application.

Using hello-world YAML file to deploy simple "Hello World" equivalent application
on already setup kubernetes cluster.

more details can be found at Medium Blog,
https://medium.com/@bhargavshah2011/hello-world-on-kubernetes-cluster-6bec6f4b1bfd

Thank You.
